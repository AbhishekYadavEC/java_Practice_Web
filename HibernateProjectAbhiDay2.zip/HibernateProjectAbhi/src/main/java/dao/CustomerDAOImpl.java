package dao;

import model.Customer;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;
import java.util.List;

@Repository
@Transactional
public class CustomerDAOImpl implements CustomerDAO{

    @Autowired
    private SessionFactory sessionFactory;
    @Override
    public void saveCustomer(Customer customer) {
        getSession ().save (customer);
    }

    @Override
    public Customer getCustomerById(int cust_id) {
        return getSession ().get (Customer.class,cust_id);
    }

    @Override
    public List getAllCustomer() {
        return getSession ().createQuery ("FROM Customer").getResultList ();
    }


    @Override
    public void updateCustomer(Customer customer) {
         getSession ().update (customer);
    }

    @Override
    public void deleteCustomer(Customer customer) {
        getSession ().delete (customer);
    }
    private Session getSession() {
        return sessionFactory.getCurrentSession();
    }
}
