package dao;

import model.Customer;
import model.LoanAgreement;

import java.util.List;

public interface CustomerDAO {
    //Create
    void saveCustomer(Customer customer);
    //Read
    Customer getCustomerById(int cust_id);
    //List Of All Customer
    List<Customer> getAllCustomer();
    //Update
    void updateCustomer(Customer customer);
    //Delete
    void deleteCustomer(Customer customer);
}
