package config;



import dao.CustomerDAO;
import dao.CustomerDAOImpl;
import dao.LoanAgreementDAO;
import dao.LoanAgreementDAOImpl;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import services.CustomerService;
import services.CustomerServiceImpl;
import services.LoanService;
import services.LoanServiceImpl;

@Configuration
@ComponentScan("model")

public class AppConfiguration {
    //Here we are using Bean for Loan Agreement Details
    @Bean
    LoanAgreementDAO loanAgreementDAO(){
        return new LoanAgreementDAOImpl ();
    }

    @Bean
    LoanService loanService(){
        return new LoanServiceImpl ();
    }

    //Here we are using for Bean for Customer Details
    @Bean
    CustomerDAO customerDAO(){
        return new CustomerDAOImpl ();
    }
    @Bean
    CustomerService customerService(){
        return new CustomerServiceImpl ();
    }

}