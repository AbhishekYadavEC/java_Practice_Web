package helper;

import model.Address;
import model.Customer;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class MainCustomerClass {
    public static void main(String[] args) {
        //Create a Hibernate Configuration
        Configuration configuration=new Configuration ();
        configuration.configure ();

        //Create Session factory from the Configuration
        SessionFactory sessionFactory=configuration.buildSessionFactory ();

        //Create a Session from the session Factory
        Session session=sessionFactory.openSession ();

        List<String > phoneNumbers=new ArrayList<> ();
        phoneNumbers.add ("2647874387");
        phoneNumbers.add ("747265734895");

        Set<String > emailAddressSets=new HashSet<> ();
        emailAddressSets.add ("Abc@gmail.com");
        emailAddressSets.add ("Abhishek@gmail.com");


        //Create a new Customer
        Customer customer=new Customer ();
        customer.setName ("Abhishek Yadav");
        customer.setDob (LocalDate.of (2001, Month.JUNE,15));
        customer.setPhoneNumbers (phoneNumbers);
        customer.setEmailAddressSet (emailAddressSets);
        customer.setAddress (new Address (121,"Bhopal","Noida","Delhi","Uttar Pradesh",2030001));
        customer.setMonthlyIncome (36000);
        customer.setProfession ("Engineer");
        customer.setDesignation ("Assistant");
        customer.setCompanyName ("Nucleus");

        //Begin a Transaction
        Transaction transaction=session.beginTransaction ();
        // Save the loan agreement
        session.save (customer);
        //Commit the transaction
        transaction.commit ();
        //Get the Customer Details By Id
        int cust_id= customer.getCust_id ( );
        Customer retrivedCustomerDetails=session.get (Customer.class,cust_id);
        System.out.println ("Retrived the Customer Details : "+retrivedCustomerDetails );

        //Update the Customer Details
        retrivedCustomerDetails.setDesignation ("Developer");

        //Begin a new Customer Details
        transaction=session.beginTransaction ();

        //Update the loanAgreement
        session.update (retrivedCustomerDetails);

        //Commit the transaction
        transaction.commit ();

        //Get All Customer Details
        System.out.println ("All Customer Details: " );
        for(Customer customer1: session.createQuery ("FROM Customer",Customer.class).list ()){
            System.out.println (customer1 );
        }
        /*//Delete the Loan Agreement
        transaction=session.beginTransaction ();
        session.delete (retrivedCustomerDetails);
        transaction.commit ();*/

        //Close the session and Session Factory
        session.close ();
        sessionFactory.close ();

    }
}
