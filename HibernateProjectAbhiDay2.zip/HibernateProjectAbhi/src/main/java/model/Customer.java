package model;
/*
Code Is Developed by Abhishek
*/
import javax.persistence.*;
import java.time.LocalDate;
import java.util.List;
import java.util.Set;

@Entity
@Table(name="CustomerEntity")
public class Customer {

    @Id
    @Column
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int cust_id;
    @Column
    private String name;

    @Column
    private LocalDate dob;
    @Column
    @ElementCollection
    private List<String> phoneNumbers;

    @Column
    @ElementCollection
    private Set<String> emailAddressSet;

    @Embedded
    @Column
    private Address address;

    @Column
    private double monthlyIncome;

    @Column
    private String profession;

    @Column
    private String designation;
    @Column
    private String companyName;
    //Create Constructor ,getter and setter
    public Customer(){
        //Create Default constructor required for Hibernate
    }

    public Customer(String name, LocalDate dob, List<String> phoneNumbers, Set<String> emailAddressSet, Address address, double monthlyIncome, String profession, String designation, String companyName) {
        this.name = name;
        this.dob = dob;
        this.phoneNumbers = phoneNumbers;
        this.emailAddressSet = emailAddressSet;
        this.address = address;
        this.monthlyIncome = monthlyIncome;
        this.profession = profession;
        this.designation = designation;
        this.companyName = companyName;
    }


    public int getCust_id() {
        return cust_id;
    }

    public void setCust_id(int cust_id) {
        this.cust_id = cust_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public LocalDate getDob() {
        return dob;
    }

    public void setDob(LocalDate dob) {
        this.dob = dob;
    }

    public List<String> getPhoneNumbers() {
        return phoneNumbers;
    }

    public void setPhoneNumbers(List<String> phoneNumbers) {
        this.phoneNumbers = phoneNumbers;
    }

    public Set<String> getEmailAddressSet() {
        return emailAddressSet;
    }

    public void setEmailAddressSet(Set<String> emailAddressSet) {
        this.emailAddressSet = emailAddressSet;
    }

    public double getMonthlyIncome() {
        return monthlyIncome;
    }

    public void setMonthlyIncome(double monthlyIncome) {
        this.monthlyIncome = monthlyIncome;
    }

    public String getProfession() {
        return profession;
    }

    public void setProfession(String profession) {
        this.profession = profession;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    @Override
    public String toString() {
        return "Customer{" +
                "cust_id=" + cust_id +
                ", name='" + name + '\'' +
                ", dob=" + dob +
                ", phoneNumbers=" + phoneNumbers +
                ", emailAddressSet=" + emailAddressSet +
                ", address=" + address +
                ", monthlyIncome=" + monthlyIncome +
                ", profession='" + profession + '\'' +
                ", designation='" + designation + '\'' +
                ", companyName='" + companyName + '\'' +
                '}';
    }
}
