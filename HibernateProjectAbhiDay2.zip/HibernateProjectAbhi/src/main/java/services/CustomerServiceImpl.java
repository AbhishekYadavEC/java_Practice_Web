package services;

import dao.CustomerDAO;
import model.Customer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;

@Service
@Transactional
public class CustomerServiceImpl implements CustomerService{
    @Autowired
    private CustomerDAO customerDAO;


    @Override
    public void saveCustomer(Customer customer) {
        customerDAO.saveCustomer (customer);
    }

    @Override
    public Customer getCustomerById(int cust_id) {
        return customerDAO.getCustomerById (cust_id);
    }

    @Override
    public List<Customer> getAllCustomer() {
        return customerDAO.getAllCustomer ();
    }

    @Override
    public void updateCustomer(Customer customer) {
        customerDAO.updateCustomer (customer);
    }

    @Override
    public void deleteCustomer(Customer customer) {
        customerDAO.deleteCustomer (customer);
    }
}
