package services;

import model.Customer;

import java.util.List;

public interface CustomerService {
    //Create
    void saveCustomer(Customer customer);
    //Read
    Customer getCustomerById(int cust_id);
    //List Of All Customer
    List<Customer> getAllCustomer();
    //Update
    void updateCustomer(Customer customer);
    //Delete
    void deleteCustomer(Customer customer);
}
