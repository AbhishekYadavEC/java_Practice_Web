package service;

import model.Loan1;

import java.util.List;

public interface LoanInterf {
    List<Loan1>getLoanList();

}
