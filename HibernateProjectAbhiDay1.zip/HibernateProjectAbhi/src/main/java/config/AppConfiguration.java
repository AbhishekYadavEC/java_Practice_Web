package config;



import dao.LoanAgreementDAO;
import dao.LoanAgreementDAOImpl;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import services.LoanService;
import services.LoanServiceImpl;

@Configuration
@ComponentScan("model")

public class AppConfiguration {
    @Bean
    LoanAgreementDAO loanAgreementDAO(){
        return new LoanAgreementDAOImpl ();
    }

    @Bean
    LoanService loanService(){
        return new LoanServiceImpl ();
    }

}