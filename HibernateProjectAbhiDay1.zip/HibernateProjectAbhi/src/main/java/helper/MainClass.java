package helper;

import model.Customer;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;


import java.time.LocalDate;
import java.time.Month;


public class MainClass {
    public static void main(String[] args) {
        Configuration cfg = new Configuration (  ).addAnnotatedClass (Customer.class).configure ();
        SessionFactory factory=cfg.buildSessionFactory ();
        Session session=factory.openSession ();
        Customer customer=new Customer ( "101","Abhishek",LocalDate.of(2001, Month.JUNE,15),540000,"Software Engineer","ASE","Nucleus Software" );
        Customer customer2=new Customer ( "102","Thamesh",LocalDate.of(2004, Month.MAY,10),350000,"Software Engineer","SE","Nucleus Software" );
        session.beginTransaction ();
        //Here we are update details of customer
        //customer2.setName ("Rahul");

        session.save (customer2);
        session.save (customer);

        /*Query query=session.createQuery ("delete from CustomerEntity where cust_id=101");
        query.executeUpdate ();
        session.getTransaction().commit();
        session.close();
        factory.close();*/

        //System.out.println("inserted!");

        //Print details of one customer by giving the customerId.
        /*Query query = session.createQuery("from Customer where cust_id=101");
        List<Customer> listemp = query.getResultList();
        listemp.forEach(System.out::println);*/

        /*//Print List of all Customers
        Query query = session.createQuery("from Customer");
        List<Customer> listemp = query.getResultList();
        listemp.forEach(System.out::println);*/

       /* //Print list of all customers who have the same designation and who belong to same company.
        Query query = session.createQuery("from Customer where designation='ASE'");
        List<Customer> listemp = query.getResultList();
        listemp.forEach(System.out::println);*/

        session.getTransaction().commit();
        session.close();
        factory.close();
    }
}
