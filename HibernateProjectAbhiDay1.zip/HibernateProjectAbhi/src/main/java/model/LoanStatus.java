package model;
/*Code Is Developed By Abhishek*/

    public enum LoanStatus{
        PENDING,
        APPROVED,
        REJECTED,
        ACTIVE,
        CLOSED
    }
